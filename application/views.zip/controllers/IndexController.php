<?php

class IndexController extends Zend_Controller_Action
{
    private $objDatos;
    private $auth;
    
    public function init()
    { 
        $this->objDatos=new Application_Model_Index();
        $this->auth=new Application_Model_Auth();
        $this->auth->validar_session();
        $this->auth->defines();
    }
    public function usuariosMenuAction()
    {
        $rs = $this->objDatos->sp_usuarios_menu($p);
        return $rs;
    }
    
    public function usuariosMenuArmadoAction($val)
    {
        //$rs=$this->usuariosMenuAction();     
		
		return $this->usuariosMenuAction();     
		   
        /*$menu='<ul id="div_cont_menu" class="docklr">';
        $indice=0;
        foreach($rs as $fila)
        {
                if($rs[$indice-1]["umo_id"]==$rs[$indice]["umo_id"])
                {
                    $menu.='<li>';
                    $menu.="<a href=# onclick=inicio.getForm(\"".$fila["url_menu"]."\",\"".$fila["alias"]."\") >";
                    $menu.='<img src="images/iconos/'.$fila["icono_menu"].'" alt="'.$fila["nombre_menu"].'" />';
                    $menu.='</a>';
                    $menu.='</li>';
                    
                }
                else
                {
                    if($indice>0)
                    {
                        $menu.='</ul>';
                    }
                    $menu.='<li>';
                    $menu.='<a href="#">';
                    $menu.='<img src="images/iconos/'.$fila["icono_modulo"].'" alt="'.$fila["nombre_modulo"].'" />';
                    $menu.='</a>';
                    $menu.='<ul>';
                    $menu.='<li>';
                    $menu.="<a href=# onclick=inicio.getForm(\"".$fila["url_menu"]."\",\"".$fila["alias"]."\") >";
                    $menu.='<img src="images/iconos/'.$fila["icono_menu"].'" alt="'.$fila["nombre_menu"].'" />';
                    $menu.='</a>';
                    $menu.='</li>';
                    
                    
                }

            if($rs[$indice+1]["umo_id"]=="" or $rs[$indice+1]["umo_id"]==null)
            {
                $menu.='</ul></li>';
            }
            $indice++;
        }
        
        $menu.='</ul>';
            return $menu;*/
    }

    public function indexAction()
    {
		Zend_Session::start();
        $this->objSess = new Zend_Session_Namespace('inventory');
		
		$rstData = $this->objDatos->sp_obtenerdatasql("select * from tipo_cambio where fecha = '".date('Y-m-d')."'");
		//echo "select * from tipo_cambio where fecha = '".date('Y-m-d')."'";
		//exit();
		if($rstData[0]["valor_compra"]>0 and $rstData[0]["valor_venta"]>0){
			$this->objSess->se_tc_c = $rstData[0]["valor_compra"];
			$this->objSess->se_tc_v = $rstData[0]["valor_venta"];
		}else{
			$this->objSess->se_tc_c = 0;
			$this->objSess->se_tc_v = 0;
		}
		
        $this->view->menu=$this->usuariosMenuArmadoAction();
		$this->view->se_age_id=$this->objSess->se_age_id;
		$this->view->se_tienda=$this->objSess->se_tienda;
		$this->view->se_valida_stock=$this->objSess->se_valida_stock;
		$this->view->sesion = $this->objSess;
    }
	
	
}