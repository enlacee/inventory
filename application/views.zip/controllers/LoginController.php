<?php

class LoginController extends Zend_Controller_Action
{
    private $objDatos;
    private $auth;
	private $sessName;
	
    public function init()
    {
		Zend_Session::start();
        $this->sessName = new Zend_Session_Namespace('inventory');
		
        $this->objDatos=new Application_Model_Login();
        $this->auth=new Application_Model_Auth();
    }

    public function indexAction($p)
    {

    }
	
	public function hora_local($zona_horaria = 0)
	{
		if ($zona_horaria > -12.1 and $zona_horaria < 12.1)
		{
			$hora_local = time() + ($zona_horaria * 3600);
			return $hora_local;
		}
		return 'error';
	}

	public function obtenerUsuarioAction()
    {
		$data = array('success' => true, 'total' => count($rs), 'data' => $rs);
        echo json_encode($data);
		
        /*$this->_helper->viewRenderer->setNoRender();
        
        $p["usuario"]=$_POST["user"];
        $rs=$this->objDatos->sp_obtener_oficina($p);        
        if($rs[0]["usr_id"]>0)
        {
			$data = array('success' => true, 'combo' => $combo, 'tienda' => $rs[0]["tie_id"]);
       		echo json_encode($data);
        }
        else
        {
            $data = array('success' => false, 'mensaje' => 'Usuario no existe');
        	echo json_encode($data);
        }*/
        
    }
	
    public function validarUsuarioAction()
    {
        $this->_helper->viewRenderer->setNoRender();
        
		
        $p["usuario"]=$_POST["user"];
		setcookie("cookie_usuario", $_POST["user"]);
        $p["clave"]=$_POST["password"];
        $rs=$this->objDatos->sp_usuarios_login($p);
		
		//echo "IMPRESION 2";
		//exit();
        /*$sessName->setExpirationSeconds(1800, 'time');
        $sessName->setExpirationSeconds(1800);
        $sessName->time = true;*/
		
        
        if($rs[0]["usr_id"]>0)
        {
			/*$dia = date('N');
			$hora_act = strtotime(gmdate('Y-m-d H:i:s', $this->hora_local(-5)));
			if($dia == 1){
				if($rs[0]["acc_lun"]){
					$dat = explode('@',$rs[0]["acc_lun"]);
					$hora_ini = strtotime(date('Y-m-d ').$dat[0]);
					$hora_fin = strtotime(date('Y-m-d ').$dat[1]);
					if(!($hora_act >= $hora_ini and $hora_act <= $hora_fin)){
						$this->_redirect("login?msn=2");
						exit();
					}
				}else{
					$this->_redirect("login?msn=2");	
					exit();
				}
			}
			
			if($dia == 2){
				if($rs[0]["acc_mar"]){
					$dat = explode('@',$rs[0]["acc_mar"]);
					$hora_ini = strtotime(date('Y-m-d ').$dat[0]);
					$hora_fin = strtotime(date('Y-m-d ').$dat[1]);
					if(!($hora_act >= $hora_ini and $hora_act <= $hora_fin)){
						$this->_redirect("login?msn=2");
						exit();
					}
				}else{
					$this->_redirect("login?msn=2");	
					exit();
				}
			}
			
			if($dia == 3){
				if($rs[0]["acc_mie"]){
					$dat = explode('@',$rs[0]["acc_mie"]);
					$hora_ini = strtotime(date('Y-m-d ').$dat[0]);
					$hora_fin = strtotime(date('Y-m-d ').$dat[1]);
					if(!($hora_act >= $hora_ini and $hora_act <= $hora_fin)){
						$this->_redirect("login?msn=2");
						exit();
					}
				}else{
					$this->_redirect("login?msn=2");	
					exit();
				}
			}
			
			if($dia == 4){
				if($rs[0]["acc_jue"]){
					$dat = explode('@',$rs[0]["acc_jue"]);
					$hora_ini = strtotime(date('Y-m-d ').$dat[0]);
					$hora_fin = strtotime(date('Y-m-d ').$dat[1]);
					if(!($hora_act >= $hora_ini and $hora_act <= $hora_fin)){
						$this->_redirect("login?msn=2");
					}
				}else{
					$this->_redirect("login?msn=2");	
				}
			}
			
			if($dia == 5){
				if($rs[0]['acc_vie']){
					$dat = explode('@',$rs[0]["acc_vie"]);
					$hora_ini = strtotime(date('Y-m-d ').$dat[0]);
					$hora_fin = strtotime(date('Y-m-d ').$dat[1]);
					if(!($hora_act >= $hora_ini and $hora_act <= $hora_fin)){
						$this->_redirect("login?msn=2");
						exit();
					}
				}else{
					$this->_redirect("login?msn=2");	
					exit();
				}
			}
			
			if($dia == 6){
				if($rs[0]["acc_sab"]){
					$dat = explode('@',$rs[0]["acc_sab"]);
					$hora_ini = strtotime(date('Y-m-d ').$dat[0]);
					$hora_fin = strtotime(date('Y-m-d ').$dat[1]);
					$cadena ="&fecha=". date("h:i:s",$hora_act)." en el rango de ".date("h:i:s",$hora_ini)." a ".date("h:i:s",$hora_fin);
					if(!($hora_act >= $hora_ini and $hora_act <= $hora_fin)){
						$this->_redirect("login?msn=2");
						exit();
					}
				}else{
					$this->_redirect("login?msn=2");	
					exit();
				}
			}
			
			if($dia == 7){
				if($rs[0]["acc_dom"]){
					$dat = explode('@',$rs[0]["acc_dom"]);
					$hora_ini = strtotime(date('Y-m-d ').$dat[0]);
					$hora_fin = strtotime(date('Y-m-d ').$dat[1]);
					if(!($hora_act >= $hora_ini and $hora_act <= $hora_fin)){
						$this->_redirect("login?msn=2");
						exit();
					}
				}else{
					$this->_redirect("login?msn=2");	
					exit();
				}
			}*/
			
            $this->sessName->se_usr_id = $rs[0]["usr_id"];
			$this->sessName->se_usp_id = $rs[0]["usp_id"];
            $this->sessName->se_nombres = $rs[0]["nombres"];
            $this->sessName->se_apellidos = $rs[0]["apellidos"];
            $this->sessName->se_cargo = $rs[0]["cargo"];
            $this->sessName->se_area = $rs[0]["area"];
			$this->sessName->se_age_id = $rs[0]["tie_id"];
			$this->sessName->se_tienda = $rs[0]["tienda"];
			$this->sessName->se_valida_stock = $rs[0]["valida_stock"];
			//$this->sessName->se_tc_c=200;
			$rstData = $this->objDatos->sp_obtenerdatasql("select * from configuracion where tie_id = ".$rs[0]["tie_id"]);
			if($rstData[0]["con_id"]>0){
				$this->sessName->se_apertura_stock = $rstData[0]["apertura_stock"];
				$this->sessName->se_apertura_clientes = $rstData[0]["apertura_clientes"];
				$this->sessName->se_apertura_proveedores = $rstData[0]["apertura_proveedores"];
				$this->sessName->se_moneda_almacen = $rstData[0]["moneda_almacen"];
				$this->sessName->se_utilidad = $rstData[0]["utilidad"];
				$this->sessName->se_desc1 = $rstData[0]["desc1"];
				$this->sessName->se_desc2 = $rstData[0]["desc2"];
				$this->sessName->se_desc3 = $rstData[0]["desc3"];
				$this->sessName->se_desc4 = $rstData[0]["desc4"];
				$this->sessName->se_calculo_precios = $rstData[0]["calculo_precios"];
				$this->sessName->se_igv = $rstData[0]["igv"];				
			}
			
			$rstData = $this->objDatos->sp_obtenerdatasql("select * from tipo_cambio where fecha = '".date('Y-m-d')."'");
			if($rstData[0]["valor_compra"]>0 and $rstData[0]["valor_venta"]>0){
				$this->sessName->se_tc_c = $rstData[0]["valor_compra"];
				$this->sessName->se_tc_v = $rstData[0]["valor_venta"];
			}else{
				$this->sessName->se_tc_c = 0;
				$this->sessName->se_tc_v = 0;
			}
			
			$rs=$this->objDatos->sp_eventos_guardar(array('usr_id'=>$rs[0]["usr_id"], 'evento'=>'A', 'tabla'=>'login', 'registro'=>$rs[0]["usr_id"], 'detalle'=>'INGRESO AL SISTEMA DE '.$rs[0]["nombres"].' '.$rs[0]["apellidos"].', TIENDA: '.$rs[0]["tienda"].">>>".date("H:i:s",$hora_act)." en el rango de ".date("H:i:s",$hora_ini)." a ".date("H:i:s",$hora_fin)));
			
            $this->auth->defines();
            $this->_redirect("/");
        }
        else
        {
            $this->_redirect("login?msn=1");
        }
        
    }

    public function getStatusSessionAction()
    {
        $this->_helper->viewRenderer->setNoRender();
        if ($this->sessName->time === true) {
            $successTime = true;
        } else {
            $successTime = false;
        }
        $array = array();
        $array['status_time'] = $successTime;
        echo json_encode($array);
    }
    
    public function expireAction()
    {
        $this->_helper->viewRenderer->setNoRender();
			
		$rs=$this->objDatos->sp_eventos_guardar(array('usr_id'=>$this->sessName->se_usr_id, 'evento'=>'S', 'tabla'=>'login', 'registro'=>$this->sessName->se_usr_id, 'detalle'=>'SALIDA DEL SISTEMA DE '.$this->sessName->se_nombres.' '.$this->sessName->se_apellidos.', TIENDA: '.$this->sessName->se_tienda));
		
        Zend_Session::namespaceUnset("inventory");
		$this->_redirect("http://inventario.importacionesinga.com.pe");
		
    }
}

?>